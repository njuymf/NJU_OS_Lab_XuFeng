#ifndef __DEVICE_H__
#define __DEVICE_H__

#include "device/serial.h"
#include "device/disk.h"
#include "device/vga.h"
#include "device/keyboard.h"
#include "device/timer.h"

#endif
